package com.devinci_codes.cms.controller;

import com.devinci_codes.cms.models.Complaint;
import com.devinci_codes.cms.models.ComplaintResponse;
import com.devinci_codes.cms.services.ComplaintService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.fasterxml.jackson.databind.ObjectMapper;


@RestController
public class ComplaintController {

    private ObjectMapper mapper;
    private ComplaintService complaintService;

    public ComplaintController() {
        this.complaintService = new ComplaintService();
        this.mapper = new ObjectMapper();
    }

    @PostMapping("/addComplaint")
        public ResponseEntity<JsonNode> addComplaint(@RequestBody JsonNode complaint) {

            complaintService.addComplaint(complaint);
            ObjectNode response = mapper.createObjectNode();
            response.put("message", "Complaint added successfully");

            return ResponseEntity.ok(response);

    }
    @PostMapping("/getComplaints")
    public ResponseEntity<JsonNode> getComplaints(@RequestBody JsonNode request) {

        ComplaintResponse[] complaints = complaintService.getAllComplaints(request);
        JsonNode complaintNode = mapper.valueToTree(complaints);
        ObjectNode response = mapper.createObjectNode();
        response.set("complaints", complaintNode);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/summaryOfComplaints")
    public ResponseEntity<JsonNode>summaryOfComplaints(@RequestBody JsonNode dates) throws JsonProcessingException {
        ObjectNode response = mapper.createObjectNode();
        Complaint[] complaints=complaintService.findTheComplaintsOfThatInterval(dates);
        JsonNode complaintNode = mapper.valueToTree(complaints);
        response.set("complaints", complaintNode);
        return ResponseEntity.ok(response);

    }

}
