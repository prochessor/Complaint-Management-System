package com.devinci_codes.cms.controller;

import com.devinci_codes.cms.models.*;
import com.devinci_codes.cms.services.JobService;
import com.devinci_codes.cms.services.UserService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class UserController {
    private UserService userService;
    private final ObjectMapper mapper;


    public UserController() {
        this.userService = new UserService();
        this.mapper = new ObjectMapper();
    }

    @PostMapping("/login")
    public ResponseEntity<JsonNode> login(@RequestBody JsonNode loginRequest) throws JsonProcessingException {
       Person person=  userService.checkUserIfValid(loginRequest);
        ObjectNode response = mapper.createObjectNode();
        if (person!=null) {
            response.put("message", "Login successful");
            JsonNode complaintNode = mapper.valueToTree(person);
            response.set("user", complaintNode);
        } else {
            response.put("message", "Login failed");
        }
        return ResponseEntity.ok(response);
    }



    @PostMapping("/getComplaintsByManager")
    public ResponseEntity<JsonNode> getComplaintsByManager(@RequestBody JsonNode request) throws JsonProcessingException {
        ComplaintResponse[] complaints = userService.getComplaintsByManager(request);

        if(complaints == null) {
            ObjectNode response = mapper.createObjectNode();
            response.put("message", "No complaints found!");
            return ResponseEntity.ok(response);

        }
        else {
            JsonNode complaintNode = mapper.valueToTree(complaints);
            ObjectNode response = mapper.createObjectNode();
            response.set("complaints", complaintNode);
            return ResponseEntity.ok(response);

        }

    }



    @PostMapping("/adminAddEmployee")
    public ResponseEntity<JsonNode>adminAddEmployee(@RequestBody JsonNode employee) throws JsonProcessingException {
        ObjectNode response = mapper.createObjectNode();
        Employee employee1=new Employee();
        employee1=userService.addEmployeeInDb(employee);
        if(employee1!=null)
        {
            response.put("message", "Employee added success");
            JsonNode complaintNode = mapper.valueToTree(employee1);
            // Create a response
            response.set("employee", complaintNode);
        }
        return ResponseEntity.ok(response);

    }

    @PostMapping("/adminAddTeacher")
    public ResponseEntity<JsonNode>adminAddTeacher(@RequestBody JsonNode teacher) throws JsonProcessingException {
        ObjectNode response = mapper.createObjectNode();
        Teacher teacher1=new Teacher();
        teacher1=userService.addTeacherInDb(teacher);
        if(teacher1!=null)
        {
            response.put("message", "Teacher added success");
            JsonNode complaintNode = mapper.valueToTree(teacher1);
            // Create a response
            response.set("teacher", complaintNode);
        }
        return ResponseEntity.ok(response);

    }
    @PostMapping("/adminRemoveTeacher")
    public void adminRemoveTeacher(@RequestBody JsonNode teacherId) throws JsonProcessingException {
        ObjectNode response = mapper.createObjectNode();
        userService.removeTeacherFromDb(teacherId);

    }
    @PostMapping("/adminRemoveEmployee")
    public void adminRemoveEmployee(@RequestBody JsonNode employeeId) throws JsonProcessingException {
        ObjectNode response = mapper.createObjectNode();
        userService.removeEmployeeFromDb(employeeId);

    }
    @PostMapping("/adminReplaceManager")
    public void adminReplaceManager(@RequestBody JsonNode data) throws JsonProcessingException {
        ObjectNode response = mapper.createObjectNode();
        userService.replaceManager(data);

    }
    @PostMapping("/getComplaintsByTeacherId")
    public ResponseEntity<JsonNode> getComplaintsByTeacherId(@RequestBody JsonNode data) throws JsonProcessingException {
        Complaint[] complaints = userService.getComplaintsByTeacher(data);

        if (complaints == null || complaints.length == 0) {
            ObjectNode response = mapper.createObjectNode();
            response.put("message", "No complaints found!");
            return ResponseEntity.ok(response);
        } else {
            JsonNode complaintNode = mapper.valueToTree(complaints);
            ObjectNode response = mapper.createObjectNode();
            response.set("complaints", complaintNode);
            return ResponseEntity.ok(response);
        }
    }

}
