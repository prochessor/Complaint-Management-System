package com.devinci_codes.cms.services;

import com.devinci_codes.cms.models.Complaint;
import com.devinci_codes.cms.models.Job;
import com.devinci_codes.cms.repositories.JobRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;

public class JobService {
    private JobRepository jobRepository;

    public JobService()
    {
        jobRepository = new JobRepository();
    }
    public void processJob(JsonNode request) {
        int jobID = request.get("jobID").asInt();

        jobRepository.updateJobStatus(jobID, "RESOLVED");

        //first the status of the job is updated -  now we will add a new notification to the manager for that we will get the manager from the job

        Job targetJob = jobRepository.getJob(jobID);

        //now we will get the manager id from here
        int managerID = targetJob.getManagerID();
        String message = request.get("message").asText();

        //now will send the notification to the manager for that we will use the notification service and send them this data
        NotificationService notificationService = new NotificationService();
        notificationService.addNotification(managerID, jobID, message, "ManagerNotification");



    }
    public void jobDone(JsonNode request) {
        int jobID = request.get("jobID").asInt();

        jobRepository.updateJobStatus(jobID, "DONE");

        //now send a notification to the teacher with the teacher id and complaint id and that information is to get
        Job targetJob = jobRepository.getJob(jobID);
        ComplaintService complaintService = new ComplaintService();
        Complaint targetComplaint= complaintService.getComplaint(targetJob.getComplaintID());

        complaintService.updateStatus(targetComplaint.getId(), targetComplaint.getType(), "RESOLVED");

        int teacherID;
        NotificationService notificationService = new NotificationService();
        notificationService.addNotification(targetComplaint.getTeacherID(), targetJob.getComplaintID(), request.get("message").asText(), "TeacherNotification");

    }
    public void addJob(JsonNode data)
    {
        int managerId = data.get("managerID").asInt();
        int complaintId = data.get("complaintID").asInt();
        ArrayNode arrayNode = (ArrayNode) data.get("employeeIDs");

        int[] employeeIds = new int[arrayNode.size()];

        for (int i = 0; i < arrayNode.size(); i++) {
            employeeIds[i] = arrayNode.get(i).asInt();
        }

        String assignedDate=data.get("assignedDate").asText();
        String jobStatus="ASSIGNED";
        String jobDescription=data.get("jobDescription").asText();
        String jobTitle=data.get("jobTitle").asText();
        Job job =new Job(managerId,complaintId,employeeIds,assignedDate,jobStatus,jobDescription,jobTitle);

        jobRepository.addJobInDataBase(job);

        //now update the status of the complaint;
        ComplaintService complaintService = new ComplaintService();
        Complaint targetComplaint= complaintService.getComplaint(complaintId);
        complaintService.updateStatus(targetComplaint.getId(), targetComplaint.getType(), "ASSIGNED");
    }
    public Job[] getJobByEmployeeID (JsonNode request)
    {
        int empID = request.get("employeeID").asInt();
        Job[] jobs = jobRepository.getJobsByEmployeeId(empID);
        return jobs;
    }

    public Job getJob(int id)
    {
        return jobRepository.getJob(id);
    }


    public Job[] getJobsByComplaintID (int complaintID)
    {
        return jobRepository.getJobsByComplaintID(complaintID);
    }
}
