package com.devinci_codes.cms.models;


public class Employee extends Person {

    public Employee(String username, String email, String password) {
        super(username,email, password);
    }
    
    public Employee() {
        super();
    }
}
