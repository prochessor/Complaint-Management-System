package com.devinci_codes.cms.controller;

import com.devinci_codes.cms.models.Department;
import com.devinci_codes.cms.models.DepartmentResponse;
import com.devinci_codes.cms.models.Feedback;
import com.devinci_codes.cms.services.DepartmentService;
import com.devinci_codes.cms.services.FeedbackService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DepartmentController {

    DepartmentService departmentService;
    ObjectMapper mapper;

    public DepartmentController()
    {
        this.departmentService = new DepartmentService();
        this.mapper = new ObjectMapper();
    }

    @GetMapping("/getDepartmentsDetails")
    public ResponseEntity<JsonNode> getDepartments() {
        DepartmentResponse[] departments =  departmentService.getAllDepartments();
        JsonNode departmentNode = mapper.valueToTree(departments);
        ObjectNode response = mapper.createObjectNode();
        response.put("departments", departmentNode);
        return ResponseEntity.ok(response);
    }
    @GetMapping("/getDepartments")
    public ResponseEntity<JsonNode> getDepartmentsLite() {
        Department[] departments =  departmentService.getAllDepartmentsLite();
        JsonNode departmentNode = mapper.valueToTree(departments);
        ObjectNode response = mapper.createObjectNode();
        response.put("departments", departmentNode);
        return ResponseEntity.ok(response);
    }


}