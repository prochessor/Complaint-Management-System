package com.devinci_codes.cms.models;

public abstract class Complaint {
    enum ComplaintStatus {
        NEW, RESOLVED, ASSIGNED, CLOSED
    }
    private String type;

    private int id;
    private String title;
    private String description;

    private String desiredOutcome;
    private int teacherID;
    private int departmentID;
    private String urgency;

    private ComplaintStatus status;

    private String DateOfArrival;
    public Complaint()
    {

    }
    public Complaint(String title, String description, String desiredOutcome, String urgency, int teacherID, int departmentID, String status,String DateOfArrival, String type)
    {
        setStatus(status);
        this.urgency = urgency;
        this.title = title;
        this.description = description;
        this.desiredOutcome = desiredOutcome;
        this.teacherID = teacherID;
        this.departmentID = departmentID;
        this.DateOfArrival=DateOfArrival;
        this.type = type;

    }
    public void setId(int id) {
        this.id = id;
    }
    public String getStatus() {
        return this.status.name();
    }
    public void setStatus(String statusString) {
        this.status = ComplaintStatus.valueOf(statusString);
    }

    public int getId()
    {
        return this.id;
    }
    public String getTitle() {
        return this.title;
    }

    public String getDescription() {
        return this.description;
    }

    public String getDesiredOutcome() {
        return this.desiredOutcome;
    }

    public String getDateOfArrival() {
        return this.DateOfArrival;
    }
    public int getTeacherID() {
        return this.teacherID;
    }

    public int getDepartmentID() {
        return this.departmentID;
    }

    public String getUrgency() {
        return this.urgency;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDesiredOutcome(String desiredOutcome) {
        this.desiredOutcome = desiredOutcome;
    }

    public void setTeacherID(int teacherID) {
        this.teacherID = teacherID;
    }

    public void setDepartmentID(int departmentID) {
        this.departmentID = departmentID;
    }

    public void setUrgency(String urgency) {
        this.urgency = urgency;
    }
    public void setDateOfArrival(String DateOfArrival) {
        this.DateOfArrival = DateOfArrival;
    }
    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }
}

