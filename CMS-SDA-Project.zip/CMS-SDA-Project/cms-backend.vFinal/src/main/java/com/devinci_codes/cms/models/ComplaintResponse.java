package com.devinci_codes.cms.models;

public class ComplaintResponse {
    private Complaint complaint;
    private Feedback[] feedbacks;

    // Constructor
    public ComplaintResponse(Complaint complaint, Feedback[] feedbacks) {
        this.complaint = complaint;
        this.feedbacks = feedbacks;
    }

    // Getters
    public Complaint getComplaint() {
        return complaint;
    }

    public Feedback[] getFeedbacks() {
        return feedbacks;
    }

    // Setters
    public void setComplaint(Complaint complaint) {
        this.complaint = complaint;
    }

    public void setFeedbacks(Feedback[] feedbacks) {
        this.feedbacks = feedbacks;
    }
}
