package com.devinci_codes.cms.controller;

import com.devinci_codes.cms.models.Feedback;
import com.devinci_codes.cms.services.FeedbackService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FeedbackController {

    FeedbackService feedbackService;
    ObjectMapper mapper;

    public FeedbackController()
    {
        this.feedbackService = new FeedbackService();
        this.mapper = new ObjectMapper();
    }

    @PostMapping("/submitFeedback")
    public ResponseEntity<JsonNode> submitFeedback(@RequestBody JsonNode feedback) {
        feedbackService.submitFeedback(feedback);

        ObjectNode response = mapper.createObjectNode();
        response.put("message", "Feedback added successfully");

        return ResponseEntity.ok(response);

    }




}