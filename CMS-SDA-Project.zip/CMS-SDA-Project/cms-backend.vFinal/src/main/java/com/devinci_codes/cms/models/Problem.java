package com.devinci_codes.cms.models;


public class Problem extends Complaint {
    private String consequences;
    public Problem() {
        super();
    }

    public Problem(String title, String description, String desiredOutcome, String urgency, int teacherID, int departmentID, String consequences, String status,String DateOfArrival, String type) {
        super(title, description, desiredOutcome, urgency, teacherID, departmentID, status,DateOfArrival, type);
        this.consequences = consequences;
    }

    public String getConsequences() {
        return this.consequences;
    }

    public void setConsequences(String consequences) {
        this.consequences = consequences;
    }


    // getters and setters
}