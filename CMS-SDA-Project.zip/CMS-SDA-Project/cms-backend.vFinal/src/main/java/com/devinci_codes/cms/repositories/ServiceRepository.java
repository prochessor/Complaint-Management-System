package com.devinci_codes.cms.repositories;

import com.devinci_codes.cms.models.Problem;
import com.devinci_codes.cms.models.Service;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ServiceRepository {
    public void addServiceInDataBase(Service service) {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/ServiceEntity.txt";
        int serviceNummber = ProblemRepository.getProblemNumber();
        serviceNummber++;
        ProblemRepository.increaseProblemNumber();
        try {
            // Append the problem data to the file
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));
            writer.write("Id: " + serviceNummber+ "\n");
            writer.write("Title: " + service.getTitle() + "\n");
            writer.write("Description: " + service.getDescription() + "\n");
            writer.write("DesiredOutcome: " + service.getDesiredOutcome() + "\n");
            writer.write("Urgency: " + service.getUrgency() + "\n");
            writer.write("TeacherID: " + service.getTeacherID() + "\n");
            writer.write("DepartmentID: " + service.getDepartmentID() + "\n");
            writer.write("Equipment Name: " + service.getEquipmentName() + "\n");
            writer.write("Status: " + service.getStatus() + "\n");
            writer.write("Equipment Details: " + service.getEquipmentDetails() + "\n");
            writer.write("DateOfArrival: " + service.getDateOfArrival()+ "\n\n");


            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    public static Service[] getAllServices() {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/ServiceEntity.txt";
        ArrayList<Service> services = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Id: ")) {
                    Service service = new Service();
                    service.setId(Integer.parseInt(line.substring(4).trim()));

                    line = reader.readLine();
                    service.setTitle(line.substring(7).trim());

                    line = reader.readLine();
                    service.setDescription(line.substring(13).trim());

                    line = reader.readLine();
                    service.setDesiredOutcome(line.substring(16).trim());

                    line = reader.readLine();
                    service.setUrgency(line.substring(9).trim());

                    line = reader.readLine();
                    service.setTeacherID(Integer.parseInt(line.substring(11).trim()));

                    line = reader.readLine();
                    service.setDepartmentID(Integer.parseInt(line.substring(14).trim()));

                    line = reader.readLine();
                    service.setEquipmentName(line.substring(16).trim());

                    line = reader.readLine();
                    service.setStatus(line.substring(8).trim());


                    line = reader.readLine();
                    service.setEquipmentDetails(line.substring(19).trim());

                    line = reader.readLine();
                    service.setDateOfArrival(line.substring(15).trim());

                    service.setType("service");
                    services.add(service);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return services.toArray(new Service[0]);
    }

    public void updateServiceStatus(int serviceId, String newStatus) {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/ServiceEntity.txt";
        List<String> updatedServices = new ArrayList<>();
        String line = null;

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            while ((line != null) || ((line = reader.readLine()) != null)) {
                if (line.startsWith("Id: ")) {
                    int id = Integer.parseInt(line.substring(4).trim());
                    StringBuilder serviceData = new StringBuilder(line + "\n");

                    while (((line = reader.readLine()) != null) && !line.startsWith("Id: ")) {
                        if (id == serviceId && line.startsWith("Status: ")) {
                            line = "Status: " + newStatus;
                        }
                        serviceData.append(line).append("\n");
                    }

                    updatedServices.add(serviceData.toString());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            for (String service : updatedServices) {
                writer.print(service);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
