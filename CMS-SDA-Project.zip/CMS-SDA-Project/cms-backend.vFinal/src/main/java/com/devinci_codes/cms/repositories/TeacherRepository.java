package com.devinci_codes.cms.repositories;
import com.devinci_codes.cms.models.Employee;
import com.devinci_codes.cms.models.Teacher;

import java.io.*;
import java.util.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class TeacherRepository {
    private static int teacherNumber = 0;
        public Teacher[] getAllTeachers() {
            String fileName = "src/main/java/com/devinci_codes/cms/entities/TeacherEntity.txt";
            ArrayList<Teacher> teachers = new ArrayList<>();

            try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.startsWith("Id: ")) {
                        Teacher teacher = new Teacher();
                        teacher.setId(Integer.parseInt(line.substring(4).trim()));

                        line = reader.readLine();
                        teacher.setUsername(line.substring(9).trim());

                        line = reader.readLine();
                        teacher.setEmail(line.substring(6).trim());

                        line = reader.readLine();
                        teacher.setPassword(line.substring(10).trim());

                        teachers.add(teacher);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return teachers.toArray(new Teacher[0]);
        }
    public void writeToDb(Teacher teacher)
    {
        teacherNumber++;
        String fileName = "src/main/java/com/devinci_codes/cms/entities/TeacherEntity.txt";
        try {
            // Append the problem data to the file
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));
            writer.write("Id: " + teacherNumber + "\n");
            writer.write("Username: " + teacher.getUsername() + "\n");
            writer.write("Email: " + teacher.getEmail() + "\n");
            writer.write("Password: " + teacher.getPassword() + "\n\n");
            writer.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }


    }


        public void removeTeacher(int teacherId) {
            String fileName = "src/main/java/com/devinci_codes/cms/entities/teacherEntity.txt";

            List<Teacher> teachers = readTeachersFromFile(fileName);

            Iterator<Teacher> iterator = teachers.iterator();
            while (iterator.hasNext()) {
                Teacher teacher = iterator.next();
                if (teacher.getId() == teacherId) {
                    iterator.remove();
                }
            }

            writeTeachersToFile(fileName, teachers);
        }

        private List<Teacher> readTeachersFromFile(String fileName) {
            List<Teacher> teachers = new ArrayList<>();

            try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.startsWith("Id: ")) {
                        Teacher teacher = new Teacher();
                        teacher.setId(Integer.parseInt(line.substring(4).trim()));

                        line = reader.readLine();
                        teacher.setUsername(line.substring(10).trim());

                        line = reader.readLine();
                        teacher.setEmail(line.substring(7).trim());

                        line = reader.readLine();
                        teacher.setPassword(line.substring(10).trim());

                        teachers.add(teacher);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return teachers;
        }

        private void writeTeachersToFile(String fileName, List<Teacher> teachers) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
                for (Teacher teacher : teachers) {
                    writer.write("Id: " + teacher.getId());
                    writer.newLine();
                    writer.write("Username: " + teacher.getUsername());
                    writer.newLine();
                    writer.write("Email: " + teacher.getEmail());
                    writer.newLine();
                    writer.write("Password: " + teacher.getPassword());
                    writer.newLine();
                    // Add more properties if needed

                    writer.newLine(); // Separate entries with an empty line
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    public Teacher getTeacher(int teacherID) {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/TeacherEntity.txt";
        Teacher target = new Teacher();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Id: ")) {
                    Teacher teacher = new Teacher();
                    teacher.setId(Integer.parseInt(line.substring(4).trim()));
                    line = reader.readLine();
                    teacher.setUsername(line.substring(9).trim());

                    line = reader.readLine();
                    teacher.setEmail(line.substring(6).trim());

                    line = reader.readLine();
                    teacher.setPassword(line.substring(10).trim());
                    if(teacher.getId() == teacherID)
                        target = teacher;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return target;
    }


}



