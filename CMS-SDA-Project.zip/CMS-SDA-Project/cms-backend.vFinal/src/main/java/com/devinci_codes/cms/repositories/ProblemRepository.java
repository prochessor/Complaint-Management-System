package com.devinci_codes.cms.repositories;

import com.devinci_codes.cms.models.Problem;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class ProblemRepository {
    private static int problemNumber = 0; // ID of the problem added when each problem is added

    public static int getProblemNumber()
    {
        return problemNumber;
    }
    public static void increaseProblemNumber()
    {
        problemNumber++;
    }

    public void addProblemInDataBase(Problem problem) {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/ProblemEntity.txt";
        problemNumber++;
        try {
            // Append the problem data to the file
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));
            writer.write("Id: " + problemNumber+ "\n");
            writer.write("Title: " + problem.getTitle() + "\n");
            writer.write("Description: " + problem.getDescription() + "\n");
            writer.write("DesiredOutcome: " + problem.getDesiredOutcome() + "\n");
            writer.write("Urgency: " + problem.getUrgency() + "\n");
            writer.write("TeacherID: " + problem.getTeacherID() + "\n");
            writer.write("DepartmentID: " + problem.getDepartmentID() + "\n");
            writer.write("Status: " + problem.getStatus() + "\n");
            writer.write("Consequences: " + problem.getConsequences() + "\n");
            writer.write("DateOfArrival: " + problem.getDateOfArrival()+ "\n\n");

            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static Problem[] getAllProblems() {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/ProblemEntity.txt";
        ArrayList<Problem> problems = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Id: ")) {
                    Problem problem = new Problem();
                    problem.setId(Integer.parseInt(line.substring(4).trim()));

                    line = reader.readLine();
                    problem.setTitle(line.substring(7).trim());

                    line = reader.readLine();
                    problem.setDescription(line.substring(13).trim());

                    line = reader.readLine();
                    problem.setDesiredOutcome(line.substring(16).trim());

                    line = reader.readLine();
                    problem.setUrgency(line.substring(9).trim());

                    line = reader.readLine();
                    problem.setTeacherID(Integer.parseInt(line.substring(11).trim()));

                    line = reader.readLine();
                    problem.setDepartmentID(Integer.parseInt(line.substring(14).trim()));

                    line = reader.readLine();
                    problem.setStatus(line.substring(8).trim());

                    line = reader.readLine();
                    problem.setConsequences(line.substring(14).trim());

                    line = reader.readLine();
                    problem.setDateOfArrival(line.substring(15).trim());

                    problem.setType("problem");

                    problems.add(problem);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return problems.toArray(new Problem[0]);
    }


    public void updateProblemStatus(int problemId, String newStatus) {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/ProblemEntity.txt";
        List<String> updatedProblems = new ArrayList<>();
        String line = null;

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            while ((line != null) || ((line = reader.readLine()) != null)) {
                if (line.startsWith("Id: ")) {
                    int id = Integer.parseInt(line.substring(4).trim());
                    StringBuilder problemData = new StringBuilder(line + "\n");

                    while (((line = reader.readLine()) != null) && !line.startsWith("Id: ")) {
                        if (id == problemId && line.startsWith("Status: ")) {
                            line = "Status: " + newStatus;
                        }
                        problemData.append(line).append("\n");
                    }

                    updatedProblems.add(problemData.toString());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            for (String problem : updatedProblems) {
                writer.print(problem);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}