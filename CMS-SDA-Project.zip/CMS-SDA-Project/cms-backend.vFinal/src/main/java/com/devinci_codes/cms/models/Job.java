package com.devinci_codes.cms.models;
import java.util.Random;

public class Job {
    private int jobId;
    private int managerId;
    private int complaintId;
    private int[] employeeIds;
    private String assignedDate;
    private String jobStatus;
    private String jobDescription;
    private String jobTitle;
    // Default constructor
    public Job() {}

    // Parameterized constructor
    public Job(int managerId, int complaintId, int[] employeeIds, String assignedDate, String jobStatus, String jobDescription,String jobTitle) {

        // Generates a random jobId between 0 and 999
        this.managerId = managerId;
        this.complaintId = complaintId;
        this.employeeIds = employeeIds;
        this.assignedDate = assignedDate;
        this.jobStatus = jobStatus;
        this.jobDescription = jobDescription;
        this.jobTitle=jobTitle;
    }



    // Getters and setters
    // ...

    // Getters and setters
    public int getJobId() {
        return jobId;
    }

    public void setJobId(int jobId) {
        this.jobId = jobId;
    }

    public int getManagerID() {
        return managerId;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String JobTitle)
    {
        this.jobTitle = jobTitle;
    }


    public void setManagerId(int managerId) {
        this.managerId = managerId;
    }

    public int getComplaintID() {
        return complaintId;
    }

    public void setComplaintId(int complaintId) {
        this.complaintId = complaintId;
    }

    public int[] getEmployeeIds() {
        return employeeIds;
    }

    public void setEmployeeIds(int[] employeeIds) {
        this.employeeIds = employeeIds;
    }

    public String getAssignedDate() {
        return assignedDate;
    }

    public void setAssignedDate(String assignedDate) {
        this.assignedDate = assignedDate;
    }

    public String getJobStatus() {
        return jobStatus;
    }

    public void setJobStatus(String jobStatus) {
        this.jobStatus = jobStatus;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }
}
