package com.devinci_codes.cms.models;

public class Manager extends Person {
    private int departmentId;

    public Manager(String username,String email, String password, int departmentId) {
        super(username,email, password);
        this.departmentId = departmentId;
    }

    public void setDepartmentID(int departmentId) {
        this.departmentId = departmentId;
    }

    public Manager() {
        super();
    }

    // getters and setters
    public int getDepartmentID() {
        return departmentId;
    }
}
