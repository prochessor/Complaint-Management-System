package com.devinci_codes.cms.controller;

import com.devinci_codes.cms.models.Job;
import com.devinci_codes.cms.services.JobService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
public class JobController {
    JobService jobService;
    ObjectMapper mapper;

    public JobController()
    {
        jobService =new JobService();
        mapper  = new ObjectMapper();
    }
    @GetMapping("/getJobs")
    public ResponseEntity<JsonNode> getJobs(@RequestBody JsonNode request) {

        ObjectNode response = mapper.createObjectNode();
        response.put("message","Success");
        return ResponseEntity.ok(response);
    }

    @PostMapping("/getJobByEmployeeID")
    public ResponseEntity<JsonNode> getJobByEmployeeID(@RequestBody JsonNode request) {

        Job[] jobs = jobService.getJobByEmployeeID(request);
        JsonNode jobNode = mapper.valueToTree(jobs);
        ObjectNode response = mapper.createObjectNode();
        response.set("jobs", jobNode);
        return ResponseEntity.ok(response);

    }

    @PostMapping("/assignJob")
    public ResponseEntity<JsonNode> assignJob(@RequestBody JsonNode request) {
        jobService.addJob(request);
        ObjectNode response = mapper.createObjectNode();
        response.put("message","Success");
        return ResponseEntity.ok(response);
    }

    @PostMapping("/processJob")
    public ResponseEntity<JsonNode> processJob(@RequestBody JsonNode request) throws JsonProcessingException {
        jobService.processJob(request);
        ObjectNode response = mapper.createObjectNode();
        response.put("message","Success");
        return ResponseEntity.ok(response);
    }

    @PostMapping("/jobDone")
    public ResponseEntity<JsonNode> jobDone(@RequestBody JsonNode request) throws JsonProcessingException {
        jobService.jobDone(request);
        ObjectNode response = mapper.createObjectNode();
        response.put("message","Success");
        return ResponseEntity.ok(response);
    }
}
