package com.devinci_codes.cms.models;

public class Service extends Complaint {
    String equipmentDetails;
    String equipmentName;

    public Service() {
        super();
    }

    public Service(String title, String description, String desiredOutcome, String urgency, int teacherID, int departmentID, String equipmentDetails, String equipmentName, String status,String DateOfArrival, String type) {
        super(title, description, desiredOutcome, urgency, teacherID, departmentID, status,DateOfArrival, type);
        this.equipmentDetails = equipmentDetails;
        this.equipmentName = equipmentName;
    }
    public String getEquipmentName()
    {
        return equipmentName;
    }
    public String getEquipmentDetails()
    {
        return equipmentDetails;
    }

    public void setEquipmentName(String value) {
        this.equipmentName = value;
    }
    public void setEquipmentDetails(String value) {
        this.equipmentDetails= value;
    }

    // getters and setters
}