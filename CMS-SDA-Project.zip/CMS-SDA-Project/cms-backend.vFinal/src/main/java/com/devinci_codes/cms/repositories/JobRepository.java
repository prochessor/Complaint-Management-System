package com.devinci_codes.cms.repositories;

import com.devinci_codes.cms.models.Job;

import java.io.*;
import java.util.*;

public class JobRepository {
    private static int problemNumber = 0;

    public JobRepository()
    {
        
    }

    public void updateJobStatus(int jobId, String status) {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/JobEntity.txt";
        List<String> updatedJobs = new ArrayList<>();
        String line = null;

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            while ((line != null) || ((line = reader.readLine()) != null)) {
                if (line.startsWith("jobId: ")) {
                    int id = Integer.parseInt(line.split(": ")[1].trim());
                    StringBuilder jobData = new StringBuilder(line + "\n");

                    while (((line = reader.readLine()) != null) && !line.startsWith("jobId: ")) {
                        if (id == jobId && line.startsWith("jobStatus: ")) {
                            line = "jobStatus: " + status;
                        }
                        jobData.append(line).append("\n");
                    }

                    updatedJobs.add(jobData.toString());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            for (String job : updatedJobs) {
                writer.print(job);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Job[] getAllJobs() {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/JobEntity.txt";
        ArrayList<Job> jobs = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("jobId: ")) {
                    Job job = new Job();
                    job.setJobId(Integer.parseInt(line.substring(7).trim()));

                    line = reader.readLine();
                    job.setManagerId(Integer.parseInt(line.substring(11).trim()));

                    line = reader.readLine();
                    job.setComplaintId(Integer.parseInt(line.substring(13).trim()));

                    line = reader.readLine();
                    String[] employeeIds = line.substring(13).trim().replace("[", "").replace("]", "").split(", ");
                    job.setEmployeeIds(Arrays.stream(employeeIds).mapToInt(Integer::parseInt).toArray());

                    line = reader.readLine();
                    job.setAssignedDate(line.substring(14).trim());

                    line = reader.readLine();
                    job.setJobStatus(line.substring(11).trim());

                    line = reader.readLine();
                    job.setJobDescription(line.substring(16).trim());

                    line = reader.readLine();
                    job.setJobTitle(line.substring(11).trim());

                    jobs.add(job);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return jobs.toArray(new Job[0]);
    }
    public Job getJob(int id) {
        Job[] jobs = getAllJobs();
        for (Job job : jobs) {
            if (job.getJobId() == id) {
                return job;
            }
        }
        return null;
    }
    public void addJobInDataBase(Job job)
    {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/JobEntity.txt";
        problemNumber++;
        try {
            // Append the problem data to the file
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));
            writer.write("jobId: " + problemNumber+ "\n");
            writer.write("managerId: " + job.getManagerID() + "\n");
            writer.write("complaintId: " + job.getComplaintID() + "\n");
            writer.write("employeeIds: " + Arrays.toString(job.getEmployeeIds()) + "\n");
            writer.write("assignedDate: " + job.getAssignedDate() + "\n");
            writer.write("jobStatus: " + job.getJobStatus() + "\n");
            writer.write("jobDescription: " + job.getJobDescription() + "\n");
            writer.write("jobTitle: " + job.getJobTitle() + "\n\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public Job[] getJobsByEmployeeId(int employeeId) {
        Job[] jobs = getAllJobs();
        ArrayList<Job> jobsForEmployee = new ArrayList<>();

        for (Job job : jobs) {
            int[] employeeIds = job.getEmployeeIds();
            for (int id : employeeIds) {
                if (id == employeeId) {
                    jobsForEmployee.add(job);
                    break;
                }
            }
        }

        return jobsForEmployee.toArray(new Job[0]);
    }

    public Job[] getJobsByComplaintID(int complaintId) {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/JobEntity.txt";
        ArrayList<Job> jobs = new ArrayList<>();

        Job[] allJobs = getAllJobs();

        for(int i=0 ; i < allJobs.length ;++i)
        {
            if(allJobs[i].getComplaintID() == complaintId)
                jobs.add(allJobs[i]);
        }


        return jobs.toArray(new Job[0]);
    }

}
