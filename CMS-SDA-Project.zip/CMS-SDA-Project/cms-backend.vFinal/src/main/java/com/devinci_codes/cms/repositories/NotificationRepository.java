package com.devinci_codes.cms.repositories;

import com.devinci_codes.cms.models.Notification;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class NotificationRepository {

    private static int notificationNumber = 0;

    public NotificationRepository(){

    }
    public void addNotificationInDataBase(Notification notification)
    {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/NotificationEntity.txt";
        notificationNumber++;
        try {
            // Append the problem data to the file
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));
            writer.write("Id: " + notificationNumber+ "\n");
            writer.write("Identifier: " + notification.getIdentifier()+ "\n");
            writer.write("PersonID: " + notification.getPersonID() + "\n");
            writer.write("MaterialID: " + notification.getMaterialID() + "\n");
            writer.write("message: " + notification.getMessage() + "\n\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public Notification[] getAllNotificationsForPerson(int personId, String identifier) {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/NotificationEntity.txt";
        ArrayList<Notification> notifications = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Id: ")) {
                    Notification notification = new Notification();
                    notification.setID(Integer.parseInt(line.substring(4).trim()));

                    line = reader.readLine();
                    String currentIdentifier = line.substring(12).trim();
                    if (!currentIdentifier.equals(identifier)) {
                        continue;
                    }

                    line = reader.readLine();
                    int id = Integer.parseInt(line.substring(10).trim());
                    if (id != personId) {
                        continue;
                    }
                    notification.setPersonID(id);

                    line = reader.readLine();
                    notification.setMaterialID(Integer.parseInt(line.substring(12).trim()));

                    line = reader.readLine();
                    notification.setMessage(line.substring(9).trim());

                    notifications.add(notification);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return notifications.toArray(new Notification[0]);
    }


    public static List<Notification> readNotificationsFromFile(String filename) {
        List<Notification> notifications = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("Id: ")) {
                    Notification notification = new Notification();
                    notification.setID(Integer.parseInt(line.split(": ")[1]));
                    notification.setIdentifier(br.readLine().split(": ")[1]);
                    notification.setPersonID(Integer.parseInt(br.readLine().split(": ")[1]));
                    notification.setMaterialID(Integer.parseInt(br.readLine().split(": ")[1]));
                    notification.setMessage(br.readLine().split(": ")[1]);
                    notifications.add(notification);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return notifications;
    }

    public static void writeNotificationsToFile(String filename, List<Notification> notifications) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            for (Notification notification : notifications) {
                writer.println("Id: " + (++notificationNumber));
                writer.println("Identifier: " + notification.getIdentifier());
                writer.println("PersonID: " + notification.getPersonID());
                writer.println("MaterialID: " + notification.getMaterialID());
                writer.println("Message: " + notification.getMessage());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void deleteNotifications(int complaintId) {
        String filename = "src/main/java/com/devinci_codes/cms/entities/NotificationEntity.txt";
        List<Notification> notifications = readNotificationsFromFile(filename);

        Iterator<Notification> iterator = notifications.iterator();
        while (iterator.hasNext()) {
            Notification notification = iterator.next();
            if (notification.getIdentifier().equals("TeacherNotification") && notification.getMaterialID() == complaintId) {
                iterator.remove();
            }

            writeNotificationsToFile(filename, notifications);
        }
    }


}
