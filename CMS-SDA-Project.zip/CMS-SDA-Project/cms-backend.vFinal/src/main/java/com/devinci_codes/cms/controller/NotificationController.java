package com.devinci_codes.cms.controller;

import com.devinci_codes.cms.models.ComplaintNotificationResponse;
import com.devinci_codes.cms.models.JobNotificationResponse;
import com.devinci_codes.cms.services.NotificationService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
public class NotificationController {
    NotificationService notificationService ;
    ObjectMapper mapper;
    public NotificationController()
    {
        this.notificationService = new NotificationService();
        this.mapper = new ObjectMapper();

    }
    @PostMapping("/getTeacherNotifications")
    public ResponseEntity<JsonNode> getTeacherNotifications(@RequestBody JsonNode request) {
        ComplaintNotificationResponse[] teacherNotificationResponses =  notificationService.getComplaintNotifications(request);

        JsonNode notificationNode = mapper.valueToTree(teacherNotificationResponses);
        ObjectNode response = mapper.createObjectNode();
        response.set("notifications", notificationNode);

        return ResponseEntity.ok(response);

    }

    @PostMapping("/getEmployeeNotifications")
    public ResponseEntity<JsonNode> getEmployeeNotifications(@RequestBody JsonNode request) {
        JobNotificationResponse[] jobNotificationResponses =  notificationService.getJobNotifications(request);

        JsonNode notificationNode = mapper.valueToTree(jobNotificationResponses);
        ObjectNode response = mapper.createObjectNode();
        response.set("notifications", notificationNode);

        return ResponseEntity.ok(response);

    }

    @PostMapping("/getManagerNotifications")
    public ResponseEntity<JsonNode> getManagerNotifications(@RequestBody JsonNode request) {
        JobNotificationResponse[] jobNotificationResponses =  notificationService.getJobNotifications(request);
        JsonNode notificationNode = mapper.valueToTree(jobNotificationResponses);



        ObjectNode response = mapper.createObjectNode();
        response.set("notifications", notificationNode);

        return ResponseEntity.ok(response);

    }

}
