package com.devinci_codes.cms.models;

public class DepartmentResponse {

    private Department department;
    private ComplaintDetailResponse[] complaintDetailResponse;

    // Getters
    public Department getDepartment() {
        return department;
    }

    public ComplaintDetailResponse[] getComplaintDetailResponse() {
        return complaintDetailResponse;
    }

    // Setters
    public void setDepartment(Department department) {
        this.department = department;
    }

    public void setComplaintDetailResponse(ComplaintDetailResponse[] complaintDetailResponse) {
        this.complaintDetailResponse = complaintDetailResponse;
    }
}
