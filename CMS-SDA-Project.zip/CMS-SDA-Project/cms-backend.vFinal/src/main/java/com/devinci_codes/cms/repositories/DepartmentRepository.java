package com.devinci_codes.cms.repositories;

import com.devinci_codes.cms.models.Department;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class DepartmentRepository {

    public Department[] getAllDepartments() {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/DepartmentEntity.txt";
        ArrayList<Department> departments = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Id: ")) {
                    Department department = new Department();
                    department.setDepartmentId(Integer.parseInt(line.substring(4).trim()));

                    line = reader.readLine();
                    department.setDepartmentName(line.substring(6).trim());

                    line = reader.readLine();
                    department.setDepartmentType(line.substring(6).trim());

                    line = reader.readLine();
                    department.setManagerId(Integer.parseInt(line.substring(11).trim()));

                    line = reader.readLine();
                    String employeeIdsStr = line.substring(13).trim();
                    employeeIdsStr = employeeIdsStr.substring(1, employeeIdsStr.length() - 1); // Remove brackets
                    String[] employeeIdsArray = employeeIdsStr.split(", ");
                    int[] employeeIds = new int[employeeIdsArray.length];
                    for (int i = 0; i < employeeIdsArray.length; i++) {
                        employeeIds[i] = Integer.parseInt(employeeIdsArray[i]);
                    }
                    department.setEmployeeIds(employeeIds);

                    departments.add(department);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return departments.toArray(new Department[0]);
    }

    public Department getDepartment(int departmentId) {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/DepartmentEntity.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Id: ")) {
                    int id = Integer.parseInt(line.substring(4).trim());
                    if (id == departmentId) {
                        Department department = new Department();
                        department.setDepartmentId(id);

                        line = reader.readLine();
                        department.setDepartmentName(line.substring(6).trim());

                        line = reader.readLine();
                        department.setDepartmentType(line.substring(6).trim());

                        line = reader.readLine();
                        department.setManagerId(Integer.parseInt(line.substring(11).trim()));

                        line = reader.readLine();
                        String employeeIdsStr = line.substring(13).trim();
                        employeeIdsStr = employeeIdsStr.substring(1, employeeIdsStr.length() - 1); // Remove brackets
                        String[] employeeIdsArray = employeeIdsStr.split(", ");
                        int[] employeeIds = new int[employeeIdsArray.length];
                        for (int i = 0; i < employeeIdsArray.length; i++) {
                            employeeIds[i] = Integer.parseInt(employeeIdsArray[i]);
                        }
                        department.setEmployeeIds(employeeIds);

                        return department;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null; // Return null if no matching department is found
    }

}
