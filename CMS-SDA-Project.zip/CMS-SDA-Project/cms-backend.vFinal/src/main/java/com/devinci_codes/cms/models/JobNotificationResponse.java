package com.devinci_codes.cms.models;

public class JobNotificationResponse {
    private int personId;
    private Job job;
    private String message;

    public int getPersonId() {
        return personId;
    }

    public void setPersonId(int personId) {
        this.personId = personId;
    }

    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    // constructor, getters and setters
}
