package com.devinci_codes.cms.services;

import com.devinci_codes.cms.models.Complaint;
import com.devinci_codes.cms.models.Feedback;
import com.devinci_codes.cms.models.Job;
import com.devinci_codes.cms.repositories.FeedbackRepository;
import com.devinci_codes.cms.repositories.JobRepository;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.Objects;

public class FeedbackService {

    private FeedbackRepository feedbackRepository;

    public  FeedbackService()
    {
        this.feedbackRepository  = new FeedbackRepository();

    }
    public void submitFeedback(JsonNode request) {

        int complaintId=request.get("complaintID").asInt();
        String description=request.get("description").asText();
        String isSatisfied=request.get("isSatisfied").asText();
        Feedback feedback1 =new Feedback(complaintId,description,isSatisfied);
        feedbackRepository.addInDb(feedback1);

        ComplaintService complaintService = new ComplaintService();
        Complaint targetComplaint= complaintService.getComplaint(complaintId);

        if (request.has("isSatisfied") && request.get("isSatisfied").asText().equals("satisfied")) {
            complaintService.updateStatus(targetComplaint.getId(), targetComplaint.getType(), "CLOSED");
        }
        else
        {
            complaintService.updateStatus(targetComplaint.getId(), targetComplaint.getType(), "NEW");
        }
        NotificationService notificationService = new NotificationService();
        notificationService.deleteNotificationForTeacherByComplaintID(complaintId);
    }

    public Feedback[] getFeedbacksByComplaint(int complaintId) {
        return feedbackRepository.getFeedbacksByComplaint(complaintId);
    }
}