package com.devinci_codes.cms.services;
import com.devinci_codes.cms.models.*;
import com.devinci_codes.cms.repositories.ProblemRepository;
import com.devinci_codes.cms.repositories.ServiceRepository;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.ArrayList;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


public class ComplaintService {

    private ProblemRepository problemRepository;
    private ServiceRepository serviceRepository;

    public ComplaintService() {
        this.problemRepository = new ProblemRepository();
        this.serviceRepository = new ServiceRepository();
    }

    public void addComplaint(JsonNode complaintData) {

        String title = complaintData.get("title").asText();
        String description = complaintData.get("description").asText();
        String desiredOutcome = complaintData.get("desiredOutcome").asText();
        String type = complaintData.get("type").asText();
        int teacherID = complaintData.get("teacherID").asInt();
        int departmentID= complaintData.get("departmentID").asInt();
        String urgency = complaintData.get("urgency").asText();
        String DateOfArrival=complaintData.get("DateOfArrival").asText();
        String status = "NEW";

        if(type.equals( "problem")) {
          String consequences = complaintData.get("consequences").asText();
          Problem complaint = new Problem(title, description, desiredOutcome,urgency, teacherID, departmentID, consequences, status,DateOfArrival, type);
          problemRepository.addProblemInDataBase(complaint);

        }
        else if(type.equals("service"))
        {
            String equipmentName = complaintData.get("equipmentName").asText();
            String equipmentDetails= complaintData.get("equipmentDetails").asText();

            Service complaint = new Service(title, description, desiredOutcome,urgency, teacherID, departmentID, equipmentDetails,equipmentName,status,DateOfArrival, type);
            serviceRepository.addServiceInDataBase(complaint);
        }
    }
    public ComplaintResponse[] getAllComplaints(JsonNode request)
    {
        int teacherID = request.get("teacherID").asInt();
        Problem[] problems = problemRepository.getAllProblems();
        Service[] services = serviceRepository.getAllServices();

        Complaint[] complaints = new Complaint[problems.length + services.length];

        System.arraycopy(problems, 0, complaints, 0, problems.length);
        System.arraycopy(services, 0, complaints, problems.length, services.length);
        ArrayList<Complaint> filteredComplaints = new ArrayList<>();

        for (Complaint complaint : complaints) {
            if (complaint.getTeacherID() == teacherID) {
                filteredComplaints.add(complaint);
            }
        }

        Complaint[] result = new Complaint[filteredComplaints.size()];
        result = filteredComplaints.toArray(result);

        FeedbackService feedbackService = new FeedbackService();
        ComplaintResponse[] complaintResponses = new ComplaintResponse[result.length];
        for (int i = 0; i < result.length; i++) {
            Complaint complaint = complaints[i];
            int complaintId = complaint.getId();

            Feedback[] feedbacks = feedbackService.getFeedbacksByComplaint(complaintId);

            complaintResponses[i] = new ComplaintResponse(complaint, feedbacks);
        }



        return complaintResponses;

    }

    public Complaint getComplaint(int complaintID)
    {

        Problem[] problems = problemRepository.getAllProblems();
        Service[] services = serviceRepository.getAllServices();

        Complaint[] complaints = new Complaint[problems.length + services.length];

        System.arraycopy(problems, 0, complaints, 0, problems.length);
        System.arraycopy(services, 0, complaints, problems.length, services.length);
        Complaint result = null;

        for (Complaint complaint : complaints) {
            if (complaint.getId() == complaintID) {
                result = complaint;
            }
        }
        return result;
    }
    public Complaint[] getComplaintsByDepartment(int departmentID) {
        List<Complaint> complaints = new ArrayList<>();
        Problem[] problems = problemRepository.getAllProblems();
        Service[] services = serviceRepository.getAllServices();

        for (Problem problem : problems) {
            if (problem.getDepartmentID() == departmentID) {
                complaints.add(problem);
            }
        }
        for (Service service : services) {
            if (service.getDepartmentID() == departmentID) {
                complaints.add(service);
            }
        }

        return complaints.toArray(new Complaint[0]);
    }


    public Complaint[] findTheComplaintsOfThatInterval(JsonNode dates) {

        String startDate=dates.get("startingDate").asText();

        String endDate=dates.get("endingDate").asText();

        Problem[] problems = problemRepository.getAllProblems();

        Service[] services = serviceRepository.getAllServices();


        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        List<Complaint> filteredComplaints = new ArrayList<>();

        try {
            Date start = dateFormat.parse(startDate);
            Date end = dateFormat.parse(endDate);

            // Iterate over Problems
            for (Problem problem : problems) {
                String problemDateString = problem.getDateOfArrival();
                if (problemDateString != null) {
                    Date problemDate = dateFormat.parse(problemDateString);
                    if (isDateInRange(problemDate, start, end)) {
                        filteredComplaints.add(problem);
                    }
                }
            }

            // Iterate over Services
            for (Service service : services) {
                String serviceDateString = service.getDateOfArrival();
                if (serviceDateString != null) {
                    Date serviceDate = dateFormat.parse(serviceDateString);
                    if (isDateInRange(serviceDate, start, end)) {
                        filteredComplaints.add(service);
                    }
                }
            }
        } catch (ParseException e) {
            e.printStackTrace(); // Handle the parse exception according to your needs
        }

        return filteredComplaints.toArray(new Complaint[0]);
    }

    private boolean isDateInRange(Date date, Date startDate, Date endDate) {
        return (date.equals(startDate) || date.after(startDate)) && (date.equals(endDate) || date.before(endDate));
    }

    public void updateStatus(int id, String type, String status)
    {
        if(type == "service")
        {
            serviceRepository.updateServiceStatus(id, status);
        }
        else
        {
            problemRepository.updateProblemStatus(id, status);
        }
    }

}