package com.devinci_codes.cms.services;

import com.devinci_codes.cms.models.*;
import com.devinci_codes.cms.repositories.DepartmentRepository;

public class DepartmentService {

    private DepartmentRepository departmentRepository;

    public DepartmentService()
    {
        this.departmentRepository = new DepartmentRepository();
    }
    public DepartmentResponse[] getAllDepartments()
    {
        Department[] departments= departmentRepository.getAllDepartments();
        DepartmentResponse[] response = new DepartmentResponse[departments.length];

        //services used
        ComplaintService complaintService = new ComplaintService();

        for (int i =0 ; i< departments.length;++i)
        {
            Complaint[] complaints = complaintService.getComplaintsByDepartment(departments[i].getDepartmentId());
            ComplaintDetailResponse[] complaintResponses = new ComplaintDetailResponse[complaints.length];

            // services used
            UserService userService = new UserService();
            JobService jobService  = new JobService();
            for (int j =0 ; j<complaints.length;++j)
            {
                //getting teacher
                int teacherID = complaints[i].getTeacherID();
                Teacher teacher = userService.getTeacher(teacherID);

                //getting manager
                int departmentID = complaints[i].getDepartmentID();
                Manager manager  = getManager(departmentID);

                //getting jobs
                Job[] jobs= jobService.getJobsByComplaintID(complaints[i].getId());
                JobResponse[] jobResponses = new JobResponse[jobs.length];


                //services used

                for(int k = 0 ; k < jobs.length ;++k)
                {
                    Employee[] employees = userService.getEmployees(jobs[k].getEmployeeIds());
                    jobResponses[k] = new JobResponse();
                    jobResponses[k].setEmployees(employees);
                    jobResponses[k].setJob(jobs[k]);
                }


                complaintResponses[j] = new ComplaintDetailResponse();
                complaintResponses[j].setComplaint(complaints[j]);
                complaintResponses[j].setTeacher(teacher);
                complaintResponses[j].setManager(manager);
                complaintResponses[j].setJobResponses(jobResponses);
            }
            response[i] = new DepartmentResponse();
            response[i].setDepartment(departments[i]);
            response[i].setComplaintDetailResponse(complaintResponses);
        }

        return response;
    }
    private Manager getManager(int departmentID)
    {
        Department department = departmentRepository.getDepartment(departmentID);
        int managerID = department.getManagerId();

        UserService userService = new UserService();
        return userService.getManager(managerID);

    }

    public Department[] getAllDepartmentsLite() {
        return departmentRepository.getAllDepartments();

    }
}
