package com.devinci_codes.cms.repositories;

import com.devinci_codes.cms.models.Manager;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class ManagerRepository {
    public Manager[] getAllManagers() {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/ManagerEntity.txt";
        ArrayList<Manager> managers = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Id: ")) {
                    Manager manager = new Manager();
                    manager.setId(Integer.parseInt(line.substring(4).trim()));

                    line = reader.readLine();
                    manager.setDepartmentID(Integer.parseInt(line.substring(14).trim()));

                    line = reader.readLine();
                    manager.setUsername(line.substring(9).trim());

                    line = reader.readLine();
                    manager.setEmail(line.substring(6).trim());

                    line = reader.readLine();
                    manager.setPassword(line.substring(10).trim());

                    managers.add(manager);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return managers.toArray(new Manager[0]);
    }
    public Manager getManager(int managerId) {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/ManagerEntity.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Id: ")) {
                    int id = Integer.parseInt(line.substring(4).trim());
                    if (id == managerId) {
                        Manager manager = new Manager();
                        manager.setId(id);

                        line = reader.readLine();
                        manager.setDepartmentID(Integer.parseInt(line.substring(14).trim()));

                        line = reader.readLine();
                        manager.setUsername(line.substring(9).trim());

                        line = reader.readLine();
                        manager.setEmail(line.substring(6).trim());

                        line = reader.readLine();
                        manager.setPassword(line.substring(10).trim());

                        return manager;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null; // Return null if no matching manager is found
    }

    private static final String FILE_PATH = "src/main/java/com/devinci_codes/cms/entities/ManagerEntity.txt";
    public void replaceCredentials(Manager newManager) {
        List<Manager> managers = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            Manager manager = null;

            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Id: ")) {
                    if (manager != null) {
                        managers.add(manager);
                    }

                    manager = new Manager();
                    manager.setId(Integer.parseInt(line.substring(4).trim()));
                } else if (line.startsWith("DepartmentID: ")) {
                    if (manager != null) {
                        manager.setDepartmentID(Integer.parseInt(line.substring(14).trim()));
                    }
                } else if (line.startsWith("Username: ")) {
                    if (manager != null) {
                        manager.setUsername(line.substring(9).trim());
                    }
                } else if (line.startsWith("Email: ")) {
                    if (manager != null) {
                        manager.setEmail(line.substring(6).trim());
                    }
                } else if (line.startsWith("Password: ")) {
                    if (manager != null) {
                        manager.setPassword(line.substring(10).trim());
                    }
                }
            }

            // Add the last manager to the list
            if (manager != null) {
                managers.add(manager);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Iterate over managers with the same department as the new manager
        for (Manager existingManager : managers) {
            if (existingManager.getDepartmentID() == newManager.getDepartmentID()) {
                // Update credentials for managers with the same department
                existingManager.setUsername(newManager.getUsername());
                existingManager.setEmail(newManager.getEmail());
                existingManager.setPassword(newManager.getPassword());
            }
        }

        // Write the updated managers back to the file
        writeManagersToFile(managers);
    }

    private void writeManagersToFile(List<Manager> managers) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Manager manager : managers) {
                writer.write("Id: " + manager.getId() + "\n");
                writer.write("DepartmentID: " + manager.getDepartmentID() + "\n");
                writer.write("Username: " + manager.getUsername() + "\n");
                writer.write("Email: " + manager.getEmail() + "\n");
                writer.write("Password: " + manager.getPassword() + "\n\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
