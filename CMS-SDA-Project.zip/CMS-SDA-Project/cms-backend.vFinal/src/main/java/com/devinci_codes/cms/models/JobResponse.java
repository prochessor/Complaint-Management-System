package com.devinci_codes.cms.models;

public class JobResponse {

    private Job job;
    private Employee[] employees;

    public JobResponse() {
    }

    // Parameterized constructor
    public JobResponse(Job job, Employee[] employees) {
        this.job = job;
        this.employees = employees;
    }

    // Getters
    public Job getJob() {
        return job;
    }

    public Employee[] getEmployees() {
        return employees;
    }

    // Setters
    public void setJob(Job job) {
        this.job = job;
    }

    public void setEmployees(Employee[] employees) {
        this.employees = employees;
    }
}

