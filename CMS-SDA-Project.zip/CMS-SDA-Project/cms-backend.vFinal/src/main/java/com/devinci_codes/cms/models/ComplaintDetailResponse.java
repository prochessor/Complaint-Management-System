package com.devinci_codes.cms.models;

public class ComplaintDetailResponse {

    private Complaint complaint;
    private Teacher teacher;
    private Manager manager;
    private JobResponse[] jobResponses;

    // Default constructor
    public ComplaintDetailResponse() {
    }

    // Parameterized constructor
    public ComplaintDetailResponse(Complaint complaint, Teacher teacher, Manager manager, JobResponse[] jobResponses) {
        this.complaint = complaint;
        this.teacher = teacher;
        this.manager = manager;
        this.jobResponses = jobResponses;
    }

    // Getters
    public Complaint getComplaint() {
        return complaint;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public Manager getManager() {
        return manager;
    }

    public JobResponse[] getJobResponses() {
        return jobResponses;
    }

    // Setters
    public void setComplaint(Complaint complaint) {
        this.complaint = complaint;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public void setManager(Manager manager) {
        this.manager = manager;
    }

    public void setJobResponses(JobResponse[] jobResponses) {
        this.jobResponses = jobResponses;
    }
}
