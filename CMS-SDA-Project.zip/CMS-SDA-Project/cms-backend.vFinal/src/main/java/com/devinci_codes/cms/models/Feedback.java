package com.devinci_codes.cms.models;

public class Feedback {
    private int id;
    private int complaintId;
    private String description;
    private String isSatisfied;

    // Constructor
    public Feedback(int complaintId, String description, String isSatisfied) {
        this.complaintId = complaintId;
        this.description = description;
        this.isSatisfied = isSatisfied;
    }

    public Feedback(){}
    // Getters

    public void setId(int id) {
        this.id = id;
    }

    public int getComplaintId() {
        return complaintId;
    }

    public String getDescription() {
        return description;
    }

    public String getIsSatisfied() {
        return isSatisfied;
    }

    // Setters
    public void setComplaintId(int complaintId) {
        this.complaintId = complaintId;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setIsSatisfied(String isSatisfied) {
        this.isSatisfied = isSatisfied;
    }
}