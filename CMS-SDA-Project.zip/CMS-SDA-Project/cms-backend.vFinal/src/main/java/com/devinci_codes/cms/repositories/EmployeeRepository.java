package com.devinci_codes.cms.repositories;

import com.devinci_codes.cms.models.Employee;
import com.devinci_codes.cms.models.Service;

import java.io.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;




public class EmployeeRepository {
    private static int employeenumber = 0;



    public Employee[] getAllEmployees() {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/EmployeeEntity.txt";
        ArrayList<Employee> employees = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Id: ")) {
                    Employee employee = new Employee();
                    employee.setId(Integer.parseInt(line.substring(4).trim()));

                    line = reader.readLine();
                    employee.setUsername(line.substring(9).trim());

                    line = reader.readLine();
                    employee.setEmail(line.substring(6).trim());

                    line = reader.readLine();
                    employee.setPassword(line.substring(10).trim());

                    employees.add(employee);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return employees.toArray(new Employee[0]);
    }

    public Employee getEmployee(int employeeId) {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/EmployeeEntity.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Id: ")) {
                    int id = Integer.parseInt(line.substring(4).trim());
                    if (id == employeeId) {
                        Employee employee = new Employee();
                        employee.setId(id);

                        line = reader.readLine();
                        employee.setUsername(line.substring(9).trim());

                        line = reader.readLine();
                        employee.setEmail(line.substring(6).trim());

                        line = reader.readLine();
                        employee.setPassword(line.substring(10).trim());

                        return employee;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null; // Return null if no matching employee is found
    }

    public void writeToDb(Employee employee)
    {
     employeenumber++;
        String fileName = "src/main/java/com/devinci_codes/cms/entities/EmployeeEntity.txt";
        try {
            // Append the problem data to the file
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));
            writer.write("Id: " + employeenumber + "\n");
            writer.write("Username: " + employee.getUsername() + "\n");
            writer.write("Email: " + employee.getEmail() + "\n");
            writer.write("Password: " + employee.getPassword() + "\n\n");

            writer.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }


    }


        public void removeEmployee(int employeeId) {
            String fileName = "src/main/java/com/devinci_codes/cms/entities/EmployeeEntity.txt";

            List<Employee> employees = readEmployeesFromFile(fileName);

            Iterator<Employee> iterator = employees.iterator();
            while (iterator.hasNext()) {
                Employee employee = iterator.next();
                if (employee.getId() == employeeId) {
                    iterator.remove();
                }
            }

            writeEmployeesToFile(fileName, employees);
        }

        private List<Employee> readEmployeesFromFile(String fileName) {
            List<Employee> employees = new ArrayList<>();

            try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.startsWith("Id: ")) {
                        Employee employee = new Employee();
                        employee.setId(Integer.parseInt(line.substring(4).trim()));

                        line = reader.readLine();
                        employee.setUsername(line.substring(9).trim());

                        line = reader.readLine();
                        employee.setEmail(line.substring(6).trim());

                        line = reader.readLine();
                        employee.setPassword(line.substring(10).trim());

                        employees.add(employee);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return employees;
        }

        private void writeEmployeesToFile(String fileName, List<Employee> employees) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
                for (Employee employee : employees) {
                    writer.write("Id: " + employee.getId());
                    writer.newLine();
                    writer.write("Username: " + employee.getUsername());
                    writer.newLine();
                    writer.write("Email: " + employee.getEmail());
                    writer.newLine();
                    writer.write("Password: " + employee.getPassword());
                    writer.newLine();
                    // Add more properties if needed

                    writer.newLine(); // Separate entries with an empty line
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

