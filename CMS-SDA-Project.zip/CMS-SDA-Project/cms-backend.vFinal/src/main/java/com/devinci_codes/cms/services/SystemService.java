package com.devinci_codes.cms.services;

import com.devinci_codes.cms.models.Department;
import com.devinci_codes.cms.repositories.DepartmentRepository;

public class SystemService {

    public void showAllDepartmentAndComplaints()
    {
        DepartmentRepository departmentRepository=new DepartmentRepository();
        Department[] departments=departmentRepository.getAllDepartments();

        for(Department department:departments)
        {

        }
    }


}
