package com.devinci_codes.cms.repositories;

import com.devinci_codes.cms.models.Feedback;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

public class FeedbackRepository {
    private static int feedback_id = 0;

    public void addInDb(Feedback feedback)
    {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/FeedbackEntity.txt";
        feedback_id++;
        try {
            // Append the problem data to the file
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));
            writer.write("FeedbackId: " + feedback_id+ "\n");
            writer.write("ComplaintId: " + feedback.getComplaintId() + "\n");
            writer.write("Description: " + feedback.getDescription() + "\n");
            writer.write("IsSatisfied: "  + feedback.getIsSatisfied() + "\n\n");

            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public Feedback[] getAllFeedbacks() {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/FeedbackEntity.txt";
        ArrayList<Feedback> feedbacks = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("FeedbackId: ")) {
                    Feedback feedback = new Feedback();
                    feedback.setId(Integer.parseInt(line.substring(12).trim()));

                    line = reader.readLine();
                    feedback.setComplaintId(Integer.parseInt(line.substring(12).trim()));

                    line = reader.readLine();
                    feedback.setDescription(line.substring(13).trim());

                    line = reader.readLine();
                    feedback.setIsSatisfied(line.substring(13).trim());

                    feedbacks.add(feedback);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return feedbacks.toArray(new Feedback[0]);
    }

    public Feedback[] getFeedbacksByComplaint(int complaintId) {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/FeedbackEntity.txt";
        ArrayList<Feedback> feedbacks = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("FeedbackId: ")) {
                    Feedback feedback = new Feedback();
                    feedback.setId(Integer.parseInt(line.substring(12).trim()));

                    line = reader.readLine();
                    int id = Integer.parseInt(line.substring(12).trim());
                    if (id != complaintId) {
                        continue;
                    }
                    feedback.setComplaintId(id);

                    line = reader.readLine();
                    feedback.setDescription(line.substring(13).trim());

                    line = reader.readLine();
                    feedback.setIsSatisfied(line.substring(13).trim());

                    feedbacks.add(feedback);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return feedbacks.toArray(new Feedback[0]);
    }

}