package com.devinci_codes.cms.models;

import org.intellij.lang.annotations.Identifier;

public class Notification {
    private int personID;
    String identifier;
    private int materialID;
    private String message;

    private int id;

    public Notification(){}
    public Notification(int personID, int materialID, String message, String identifier) {
        this.personID = personID;
        this.materialID = materialID;
        this.message = message;
        this.identifier = identifier;
    }

    public int getPersonID() {
        return personID;
    }

    public void setPersonID(int personID) {
        this.personID = personID;
    }

    public int getMaterialID() {
        return materialID;
    }

    public void setMaterialID(int jobID) {
        this.materialID = jobID;
    }

    public String getMessage() {
        return message;
    }

    public void setID(int id)
    {
        this.id = id;
    }
    public void setMessage(String message) {
        this.message = message;
    }

    public String getIdentifier() {
        return  identifier;
    }

    public void setIdentifier(String s) {
        identifier=s;
    }
}
