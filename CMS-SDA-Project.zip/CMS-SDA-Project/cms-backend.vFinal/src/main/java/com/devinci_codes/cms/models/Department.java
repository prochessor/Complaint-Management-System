package com.devinci_codes.cms.models;


public class Department {
    private int departmentId;
    private int[] employeeIds;
    private int managerId;
    private String departmentName;
    private String departmentType;

    // Constructors
    public Department() {
        // Default constructor
    }

    public Department(int departmentId, int[] employeeIds, int managerId,
                      String departmentName, String departmentType) {
        this.departmentId = departmentId;
        this.employeeIds = employeeIds;
        this.managerId = managerId;
        this.departmentName = departmentName;
        this.departmentType = departmentType;
    }

    // Getter and Setter methods
    public int getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(int departmentId) {
        this.departmentId = departmentId;
    }

    public int[] getEmployeeIds() {
        return employeeIds;
    }

    public void setEmployeeIds(int[] employeeIds) {
        this.employeeIds = employeeIds;
    }

    public int getManagerId() {
        return managerId;
    }

    public void setManagerId(int managerId) {
        this.managerId = managerId;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getDepartmentType() {
        return departmentType;
    }

    public void setDepartmentType(String departmentType) {
        this.departmentType = departmentType;
    }

    // toString method for better representation

}