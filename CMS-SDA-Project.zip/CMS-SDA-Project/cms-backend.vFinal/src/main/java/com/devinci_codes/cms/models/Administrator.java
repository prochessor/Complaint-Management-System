package com.devinci_codes.cms.models;

public class Administrator extends Person{

    public Administrator(String username,String email, String password) {
        super(username,email, password);
    }

    public Administrator() {
        super();
    }


}

