package com.devinci_codes.cms.models;

public class Director extends Person{

    public Director(String username,String email, String password) {
        super(username,email, password);
    }

    public Director() {
        super();
    }


}
