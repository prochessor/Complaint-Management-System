package com.devinci_codes.cms.models;


public class Teacher extends Person {


    public Teacher(String username,String email, String password) {
        super(username,email, password);
    }

    public Teacher() {
        super();
    }

    // getters and setters
}
