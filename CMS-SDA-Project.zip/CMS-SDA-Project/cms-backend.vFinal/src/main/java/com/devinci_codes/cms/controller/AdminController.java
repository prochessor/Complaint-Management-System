package com.devinci_codes.cms.controller;

import com.devinci_codes.cms.services.SystemService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
public class AdminController {

    private final SystemService systemService;
    private final ObjectMapper mapper;

    public AdminController() {
        this.systemService = new SystemService();
        this.mapper = new ObjectMapper();
    }


    @PostMapping("/getAllDepartmentsAndTheirComplaints")
    public ResponseEntity<JsonNode> getAllDepartmentsAndTheirComplaints(@RequestBody JsonNode loginRequest) throws JsonProcessingException {
        systemService.showAllDepartmentAndComplaints();
        return null;
    }
}
