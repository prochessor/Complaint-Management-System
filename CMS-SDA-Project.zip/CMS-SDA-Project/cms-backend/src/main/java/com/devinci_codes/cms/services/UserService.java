package com.devinci_codes.cms.services;

import com.devinci_codes.cms.models.*;
import com.devinci_codes.cms.repositories.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.devinci_codes.cms.repositories.ServiceRepository;
import java.util.*;


public class UserService {

    public UserService() {

    }


    public Person checkUserIfValid(JsonNode loginRequest) {

        String email = loginRequest.get("email").asText();
        String password = loginRequest.get("password").asText();

        if(email.contains("@teacher.com")){

            TeacherRepository teacherRepository = new TeacherRepository();
            Teacher[] teachers = teacherRepository.getAllTeachers();

            for (Teacher teacher : teachers) {
                if (teacher.getEmail().equals(email) && teacher.getPassword().equals(password)) {
                    return teacher;
                }
            }
        } else if(email.contains("@administrator.com")){

            AdministratorRepository administratorRepository = new AdministratorRepository();
            Administrator[] administrators = administratorRepository.getAllAdministrators();

            for (Administrator administrator : administrators) {
                System.out.println("email: " + administrator.getEmail());
                System.out.println("password: " + administrator.getPassword());

                if (administrator.getEmail().equals(email) && administrator.getPassword().equals(password)) {

                    return administrator;

                }
            }
        } else if(email.contains("@director.com")){

            DirectorRepository directorRepository = new DirectorRepository();
            Director[] directors = directorRepository.getAllDirectors();

            for (Director director : directors) {
                if (director.getEmail().equals(email) && director.getPassword().equals(password)) {
                    return director;
                }
            }
        } else if(email.contains("@manager.com")){

            ManagerRepository managerRepository = new ManagerRepository();
            Manager[] managers = managerRepository.getAllManagers();

            for (Manager manager : managers) {
                if (manager.getEmail().equals(email) && manager.getPassword().equals(password)) {
                    return manager;
                }
            }
        } else if(email.contains("@employee.com")){

            EmployeeRepository employeeRepository = new EmployeeRepository();
            Employee[] employees = employeeRepository.getAllEmployees();

            for (Employee employee : employees) {
                if (employee.getEmail().equals(email) && employee.getPassword().equals(password)) {
                    return employee;
                }
            }
        }

        // If no matching user is found, return null or handle the case as needed
        return null;

    }
    public int getDepartmentByManagerID(int managerId) {
        ManagerRepository managerRepository = new ManagerRepository();
        Manager[] managers = managerRepository.getAllManagers();

        for (Manager manager : managers) {
            if (manager.getId() == managerId) {
                return manager.getDepartmentID();
            }
        }
        return -1; // If managerId is not found
    }

    public ComplaintResponse[] getComplaintsByManager(JsonNode request) {
        int managerID = request.get("managerID").asInt();
        int departmentID = getDepartmentByManagerID(managerID);

        ComplaintService complaintService = new ComplaintService();
        Complaint[] complaints = complaintService.getComplaintsByDepartment(departmentID);

        FeedbackService feedbackService = new FeedbackService();
        ComplaintResponse[] complaintResponses = new ComplaintResponse[complaints.length];
        for (int i = 0; i < complaints.length; i++) {
            Complaint complaint = complaints[i];
            int complaintId = complaint.getId();

            Feedback[] feedbacks = feedbackService.getFeedbacksByComplaint(complaintId);
            // Now you have the feedbacks for the current complaint

            complaintResponses[i] = new ComplaintResponse(complaint, feedbacks);
        }

        return complaintResponses;
    }



    public Employee addEmployeeInDb(JsonNode employee) {

        String username=employee.get("username").asText();
        String email=employee.get("email").asText();
        String password=employee.get("password").asText();
        Employee emp=new Employee(username,email,password);
        EmployeeRepository employeeRepository=new EmployeeRepository();
        employeeRepository.writeToDb(emp);
        return emp;

    }

    public Teacher addTeacherInDb(JsonNode teacher) {

        String username=teacher.get("username").asText();
        String email=teacher.get("email").asText();
        String password=teacher.get("password").asText();
        Teacher tchr=new Teacher(username,email,password);
        TeacherRepository teacherRepository=new TeacherRepository();
        teacherRepository.writeToDb(tchr);
        return tchr;
    }

    public void removeTeacherFromDb(JsonNode teacherId) {

        int teacherId1=teacherId.get("teacherId").asInt();
        TeacherRepository teacherRepository=new TeacherRepository();
        teacherRepository.removeTeacher(teacherId1);
    }

    public void removeEmployeeFromDb(JsonNode employeeId) {
        int employeeId1=employeeId.get("employeeId").asInt();
        EmployeeRepository employeeRepository=new EmployeeRepository();
        employeeRepository.removeEmployee(employeeId1);
    }


    public Teacher getTeacher(int teacherID)
    {
        TeacherRepository teacherRepository= new TeacherRepository();
        return teacherRepository.getTeacher(teacherID);
    }
    public Manager getManager(int managerID)
    {
        ManagerRepository managerRepository= new ManagerRepository();
        return managerRepository.getManager(managerID);
    }

    public Employee[] getEmployees(int[] ids) {
        EmployeeRepository employeeRepository = new EmployeeRepository();
        ArrayList<Employee> employees = new ArrayList<>();
        for (int id : ids) {
            Employee employee = employeeRepository.getEmployee(id);
            if (employee != null) {
                employees.add(employee);
            }
        }
        return employees.toArray(new Employee[0]);
    }


}
