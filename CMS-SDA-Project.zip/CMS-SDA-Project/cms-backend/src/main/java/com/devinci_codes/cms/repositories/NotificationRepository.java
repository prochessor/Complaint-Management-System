package com.devinci_codes.cms.repositories;

import com.devinci_codes.cms.models.Notification;

import java.io.*;
import java.util.ArrayList;

public class NotificationRepository {

    private static int notificationNumber = 0;

    public NotificationRepository(){

    }
    public void addNotificationInDataBase(Notification notification)
    {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/NotificationEntity.txt";
        notificationNumber++;
        try {
            // Append the problem data to the file
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));
            writer.write("Id: " + notificationNumber+ "\n");
            writer.write("PersonID: " + notification.getPersonID() + "\n");
            writer.write("MaterialID: " + notification.getMaterialID() + "\n");
            writer.write("message: " + notification.getMessage() + "\n\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public Notification[] getAllNotificationsForPerson(int personId, String identifier) {
        String fileName = "src/main/java/com/devinci_codes/cms/entities/NotificationEntity.txt";
        ArrayList<Notification> notifications = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Id: ")) {
                    Notification notification = new Notification();
                    notification.setID(Integer.parseInt(line.substring(4).trim()));

                    line = reader.readLine();
                    String currentIdentifier = line.substring(12).trim();
                    if (!currentIdentifier.equals(identifier)) {
                        continue;
                    }

                    line = reader.readLine();
                    int id = Integer.parseInt(line.substring(10).trim());
                    if (id != personId) {
                        continue;
                    }
                    notification.setPersonID(id);

                    line = reader.readLine();
                    notification.setMaterialID(Integer.parseInt(line.substring(12).trim()));

                    line = reader.readLine();
                    notification.setMessage(line.substring(9).trim());

                    notifications.add(notification);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return notifications.toArray(new Notification[0]);
    }


}
