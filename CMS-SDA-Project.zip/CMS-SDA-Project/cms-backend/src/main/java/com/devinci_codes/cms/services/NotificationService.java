package com.devinci_codes.cms.services;

import com.devinci_codes.cms.models.*;
import com.devinci_codes.cms.repositories.NotificationRepository;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.ArrayList;
import java.util.List;
public class NotificationService {
    NotificationRepository notificationRepository;

    public NotificationService()
    {
        notificationRepository = new NotificationRepository();
    }


    public void addNotification(int personID, int jobID, String message, String identifier)
    {
        Notification notification = new Notification(personID, jobID, message, identifier);
        notificationRepository.addNotificationInDataBase(notification);
    }


    public ComplaintNotificationResponse[] getComplaintNotifications(JsonNode request) {
        int teacherID = request.get("teacherID").asInt();

        Notification[] notifications = notificationRepository.getAllNotificationsForPerson(teacherID, "TeacherNotification");
        List<ComplaintNotificationResponse> notificationDataList = new ArrayList<>();
        ComplaintService complaintService = new ComplaintService();


        for (Notification notification : notifications) {
            int materialId = notification.getMaterialID();

            Complaint complaint = complaintService.getComplaint(materialId);

            ComplaintNotificationResponse notificationData = new ComplaintNotificationResponse();
            notificationData.setPersonId(notification.getPersonID());
            notificationData.setComplaint(complaint);
            notificationData.setMessage(notification.getMessage());

            notificationDataList.add(notificationData);
        }

        return notificationDataList.toArray(new ComplaintNotificationResponse[0]);
    }

    public JobNotificationResponse[] getJobNotifications(JsonNode request)
    {
        int employeeID = request.get("managerID").asInt();

        Notification[] notifications = notificationRepository.getAllNotificationsForPerson(employeeID, "ManagerNotification");

        List<JobNotificationResponse> notificationDataList = new ArrayList<>();
        JobService jobService = new JobService();


        for (Notification notification : notifications) {
            int materialId = notification.getMaterialID();

            Job job = jobService.getJob(materialId);

            JobNotificationResponse notificationData = new JobNotificationResponse();
            notificationData.setPersonId(notification.getPersonID());
            notificationData.setJob(job);
            notificationData.setMessage(notification.getMessage());

            notificationDataList.add(notificationData);
        }

        return notificationDataList.toArray(new JobNotificationResponse[0]);
    }
}
