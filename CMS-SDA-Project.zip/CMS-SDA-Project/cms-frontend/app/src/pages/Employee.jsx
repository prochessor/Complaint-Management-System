import React from "react";

const Employee = ({ user }) => {
  return <div>Employee</div>;
};

export default Employee;
