import React from "react";

const Director = ({ user }) => {
  return <div>Director</div>;
};

export default Director;
