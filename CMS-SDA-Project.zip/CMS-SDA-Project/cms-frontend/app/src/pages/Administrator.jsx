import React from "react";

const Administrator = ({ user }) => {
  return <div>Administrator</div>;
};

export default Administrator;
