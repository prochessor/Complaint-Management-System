import React from "react";

const Manager = ({ user }) => {
  return <div>Manager</div>;
};

export default Manager;
